# frontend.py

import os
import re
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFrame, QLabel, QLineEdit, QPushButton, QScrollArea, QMenu, QApplication
)
from PyQt6.QtCore import (
    Qt, QPropertyAnimation, QEasingCurve, pyqtSignal, QTimer, QSize
)
from PyQt6.QtGui import (
    QPixmap, QCursor, QColor
)

class DraggableMascot(QLabel):
    clicked = pyqtSignal()

    def __init__(self, pixmap, host_window, parent=None):
        super().__init__(parent)
        self.setPixmap(pixmap)
        self.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.host_window = host_window
        self._drag_pos = None
        self._moved = False

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = (
                event.globalPosition().toPoint()
                - self.host_window.frameGeometry().topLeft()
            )
            self._moved = False
            event.accept()
        elif event.button() == Qt.MouseButton.RightButton:
            event.accept()

    def mouseMoveEvent(self, event):
        if (
            event.buttons() == Qt.MouseButton.LeftButton
            and self._drag_pos is not None
        ):
            self.host_window.move(
                event.globalPosition().toPoint()
                - self._drag_pos
            )
            self._moved = True
            event.accept()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            if not self._moved:
                self.clicked.emit()

            self._drag_pos = None
            self._moved = False
            event.accept()

    def contextMenuEvent(self, event):
        menu = QMenu(self)
        menu.setStyleSheet("""
            QMenu {
                background-color: #ffffff; color: #222222;
                border-radius: 8px; border: 1px solid #cccccc; padding: 4px;
            }
            QMenu::item { padding: 6px 20px; border-radius: 4px; }
            QMenu::item:selected { background-color: #dc1414; color: white; }
        """)
        close_action = menu.addAction("Uygulamayı Kapat")
        action = menu.exec(event.globalPos())
        if action == close_action:
            QApplication.quit()

class ChatFrontend(QWidget):
    PANEL_WIDTH = 340
    HEIGHT_CLOSED = 0
    HEIGHT_COMPACT = 70      # Sadece arama çubuğu boyutu
    # ÇÖZÜM 1: Expanded yüksekliğini biraz daha artırarak güvenli bir alan bırakalım.
    HEIGHT_EXPANDED = 500    
    MASCOT_SIZE = 130

    def __init__(self):
        super().__init__()

        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)

        self.current_state = "CLOSED"
        self.suggestion_widgets = []

        # Penceremizin ana boyutunu expanded yüksekliğe göre ayarlayalım
        self.setFixedSize(self.PANEL_WIDTH + self.MASCOT_SIZE + 30, self.HEIGHT_EXPANDED + 30)

        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(10)
        main_layout.setAlignment(Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignRight)

        # ----------------------------------------------------
        # 1. Kırmızı Sohbet/Arama Paneli
        # ----------------------------------------------------
        self.panel = QFrame()
        self.panel.setObjectName("chatPanel")
        self.panel.setFixedWidth(self.PANEL_WIDTH)
        self.panel.setMaximumHeight(self.HEIGHT_CLOSED)  # Başlangıçta 0
        self.panel.setStyleSheet("""
            QFrame#chatPanel {
                background-color: #dc1414;
                border-radius: 30px;
            }
        """)

        # ÇÖZÜM 2: Layout'u daha esnek yapıyoruz ve marginsleri artırıyoruz.
        panel_layout = QVBoxLayout(self.panel)
        panel_layout.setContentsMargins(15, 15, 15, 15) # İçeriye biraz daha boşluk verelim
        panel_layout.setSpacing(10)
        
        # --- Mesaj Alanı ---
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setVisible(False)
        self.scroll_area.setStyleSheet("""
            QScrollArea { background: transparent; border: none; }
            QScrollBar:vertical { width: 6px; background: transparent; }
            QScrollBar::handle:vertical { background: rgba(255,255,255,100); border-radius: 3px; }
        """)

        self.scroll_content = QWidget()
        self.scroll_content.setStyleSheet("background: transparent;")
        
        # ÇÖZÜM 3: Mesaj layout'unun genişlemesine izin veriyoruz
        self.messages_layout = QVBoxLayout(self.scroll_content)
        self.messages_layout.setContentsMargins(0, 0, 0, 0)
        self.messages_layout.setSpacing(8)
        self.messages_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        
        self.scroll_area.setWidget(self.scroll_content)
        # ÇÖZÜM 4: ScrollArea'ya genişleme önceliği veriyoruz
        panel_layout.addWidget(self.scroll_area, 1)

        # --- Arama Çubuğu ---
        input_container = QWidget()
        input_container.setObjectName("inputContainer")
        input_container.setFixedHeight(40)
        input_container.setStyleSheet("""
            QWidget#inputContainer {
                background-color: transparent;
                border: 1px solid white;
                border-radius: 20px;
            }
        """)
        input_layout = QHBoxLayout(input_container)
        input_layout.setContentsMargins(15, 2, 8, 2)
        input_layout.setSpacing(5)

        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText("Jelly'e soru sor...")
        self.input_field.setStyleSheet("""
            QLineEdit {
                background-color: transparent;
                color: white;
                border: none;
                font-size: 15px;
            }
            QLineEdit::placeholder { color: rgba(255, 255, 255, 180); }
        """)
        input_layout.addWidget(self.input_field)

        self.send_button = QPushButton("🔍\uFE0E")
        self.send_button.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.send_button.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: white;
                border: none;
                font-size: 18px;
            }
            QPushButton:hover { color: #cccccc; }
        """)
        input_layout.addWidget(self.send_button)

        # Arama çubuğunu en alta ekliyoruz
        panel_layout.addWidget(input_container)

        # ----------------------------------------------------
        # 2. Maskot - Jelly (Değişmedi)
        # ----------------------------------------------------
        pixmap = QPixmap(os.path.join(os.path.dirname(__file__), "jelly.png"))
        if pixmap.isNull():
            pixmap = QPixmap(self.MASCOT_SIZE, self.MASCOT_SIZE)
            pixmap.fill(QColor(220, 30, 30))
        else:
            pixmap = pixmap.scaledToWidth(self.MASCOT_SIZE, Qt.TransformationMode.SmoothTransformation)

        self.mascot = DraggableMascot(pixmap, host_window=self)
        self.mascot.clicked.connect(self.toggle_panel)

        main_layout.addWidget(self.panel)
        main_layout.addWidget(self.mascot)

        self.anim = QPropertyAnimation(self.panel, b"maximumHeight")
        self.anim.setDuration(300)
        self.anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        
        # YENİ EKLENEN KISIM: Animasyon bittiğinde alta kaydır
        self.anim.finished.connect(self._en_alta_kaydir)

    def toggle_panel(self):
        if self.current_state == "CLOSED":
            self.open_compact()
        else:
            self.close_panel()

    def open_compact(self):
        self.current_state = "COMPACT"
        self.scroll_area.setVisible(False)
        self._animate_to(self.HEIGHT_COMPACT)
        self.input_field.setFocus()

    def expand_panel(self):
        if self.current_state != "EXPANDED":
            self.current_state = "EXPANDED"
            self.scroll_area.setVisible(True)
            self._animate_to(self.HEIGHT_EXPANDED)

    def close_panel(self):
        self.current_state = "CLOSED"
        self._animate_to(self.HEIGHT_CLOSED)

    def _animate_to(self, target_h):
        self.anim.stop()
        self.anim.setStartValue(self.panel.maximumHeight())
        self.anim.setEndValue(target_h)
        self.anim.start()

    # YENİ EKLENEN FONKSİYON: Animasyon bittikten sonra kaydırmayı tetikler
    def _en_alta_kaydir(self):
        QApplication.processEvents()
        scrollbar = self.scroll_area.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    # ÖNCEKİ DÜZELTME (add_message içinde QLabel sarmalama) aynı kalıyor.
    # Ancak ÇÖZÜM 5'i (dinamik scroll) ekliyoruz.
    def add_message(self, text):
        self.expand_panel()
        
        bubble_container = QFrame()
        bubble_container.setStyleSheet("""
            QFrame {
                background-color: #ffffff;
                border-radius: 12px;
            }
        """)
        
        bubble_layout = QVBoxLayout(bubble_container)
        bubble_layout.setContentsMargins(14, 14, 14, 14) 
        bubble_layout.setSpacing(0)

        msg_label = QLabel(text)
        msg_label.setWordWrap(True)
        msg_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        
        msg_label.setStyleSheet("""
            QLabel {
                background-color: transparent;
                color: #222222;
                font-size: 13px;
            }
        """)
         
        bubble_layout.addWidget(msg_label)
        self.messages_layout.addWidget(bubble_container)

        # ÇÖZÜM 5: Mesaj eklendikten sonra scroll_content'in minimum yüksekliğini
        # içindeki layout'un gerçek yüksekliğine (sizeHint().height()) göre güncelleyelim.
        # Bu, scrollarea'nın içeriğin tamamını algılamasını sağlar.
        QApplication.processEvents() # Layout'un hesaplanmasını zorunlu kılalım
        self.scroll_content.setMinimumHeight(self.messages_layout.sizeHint().height())

        # Scrollbar'ı en alta indirme işlemi (Zamanlayıcıyı biraz daha uzatabiliriz)
        QTimer.singleShot(  
            100, # 50'den 100'e çıkardık, layout'un tamamen yerleşmesi için zaman tanıyoruz
            lambda: self.scroll_area.verticalScrollBar().setValue(
                self.scroll_area.verticalScrollBar().maximum()    
            )
        )

    def clear_suggestions(self):
        for w in self.suggestion_widgets:
            w.setParent(None)
        self.suggestion_widgets = []

    def show_suggestions(self, sorular, callback):
        self.clear_suggestions()
        for soru in sorular:
            btn = QPushButton(soru)
            btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
            btn.setStyleSheet("""
                QPushButton {
                    background-color: rgba(255, 255, 255, 180); color: #222222;
                    border: none; border-radius: 12px; padding: 6px 12px;
                    font-size: 12px; text-align: left;
                }
                QPushButton:hover { background-color: #ffffff; }
            """)
            btn.clicked.connect(lambda checked=False, s=soru: callback(s))
            self.messages_layout.addWidget(btn)
            self.suggestion_widgets.append(btn)

        QApplication.processEvents()
        
        # ÇÖZÜM 5'in benzeri: Öneriler eklendikten sonra da yüksekliği güncellemeliyiz.
        self.scroll_content.setMinimumHeight(self.messages_layout.sizeHint().height())

        scrollbar = self.scroll_area.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())