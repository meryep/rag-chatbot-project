import sys
import os

from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import QThread, pyqtSignal

from dotenv import load_dotenv

from frontend import ChatFrontend
from rag_engine import RAGChatbot

from router import QuestionRouter
from llm_service import SAPAssistant

load_dotenv()


class GroqWorker(QThread):

    finished = pyqtSignal(str)

    def __init__(
        self,
        question,
        router,
        sap_assistant,
        rag_assistant
    ):
        super().__init__()

        self.question = question
        self.router = router
        self.sap_assistant = sap_assistant
        self.rag_assistant = rag_assistant

    def run(self):

        try:

            route = self.router.route(
                self.question
            )

            if route == "rag":

                cevap, _, _ = self.rag_assistant.soru_sor(
                    self.question
                )

            else:

                cevap = self.sap_assistant.ask(
                    self.question
                )

        except Exception as e:

            cevap = f"Hata oluştu: {str(e)}"

        self.finished.emit(cevap)


class MascotController:

    def __init__(self):

        self.ui = ChatFrontend()

        self.router = QuestionRouter()

        self.sap_assistant = SAPAssistant(
            os.getenv("GROQ_API_KEY")
        )

        self.rag_assistant = RAGChatbot(
            veri_yolu="kaynak.md",
            groq_api_key=os.getenv("GROQ_API_KEY")
        )

        self.worker = None

        self.ui.input_field.returnPressed.connect(
            self.send_message
        )

        self.ui.send_button.clicked.connect(
            self.send_message
        )

    def send_message(self):

        user_text = (
            self.ui.input_field.text()
            .strip()
        )

        if not user_text:
            return

        if hasattr(self.ui, "add_chat_message"):
            self.ui.add_chat_message(
                user_text,
                "user"
            )
        else:
            self.ui.add_message(
                f"Sen: {user_text}"
            )

        self.ui.input_field.clear()

        self.ui.input_field.setEnabled(False)
        self.ui.send_button.setEnabled(False)

        if hasattr(self.ui, "show_typing"):
            self.ui.show_typing()

        self.worker = GroqWorker(
            question=user_text,
            router=self.router,
            sap_assistant=self.sap_assistant,
            rag_assistant=self.rag_assistant
        )

        self.worker.finished.connect(
            self.handle_response
        )

        self.worker.start()

    def handle_response(self, response_text):

        if hasattr(self.ui, "hide_typing"):
            self.ui.hide_typing()

        if hasattr(self.ui, "add_chat_message"):
            self.ui.add_chat_message(
                response_text,
                "assistant"
            )
        else:
            self.ui.add_message(
                f"Jelly: {response_text}"
            )

        self.ui.input_field.setEnabled(True)
        self.ui.send_button.setEnabled(True)
        self.ui.input_field.setFocus()

    def show(self):

        screen = (
            QApplication.primaryScreen()
            .geometry()
        )

        self.ui.move(
            screen.width()
            - self.ui.width()
            - 30,

            screen.height()
            - self.ui.height()
            - 60
        )

        self.ui.show()


if __name__ == "__main__":

    app = QApplication(sys.argv)

    controller = MascotController()
    controller.show()

    sys.exit(app.exec())