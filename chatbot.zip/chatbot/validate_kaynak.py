"""
kaynak.md doğrulama scripti (Faz 1.3)

Kullanım:
    python validate_kaynak.py kaynak.md

Ne kontrol eder:
  1. Aynı başlık iki kere kullanılmış mı? (örn. iki tane "### SU01")
  2. Boş/eksik "Açıklama" (İşlem Kodu girişleri) veya "Mesaj Metni" (Hata
     Mesajı girişleri) var mı?
  3. "##" kategorisi olmadan "###" başlığı var mı? (kategori dışı kalmış kayıt)
  4. Toplam kayıt sayısı, kategori bazında kırılım.

Herhangi bir hata bulunursa script exit code 1 ile çıkar (CI/otomasyon için).
"""
import sys
import re


ONEK_PATTERN = re.compile(r"^(İşlem Kodu|Hata Mesajı|T-Code|T-Kodu|Kod)\s*:\s*", re.IGNORECASE)


def parcala(icerik: str):
    """kaynak.md'yi ### başlıklarına göre böler, her parçanın kategorisini,
    başlığını ve ham metnini kayıt altına alır."""
    lines = icerik.split("\n")
    kayitlar = []
    kategori = None
    kategori_satiri = None
    baslik = None
    baslik_satiri = None
    buffer = []

    def flush():
        if baslik is not None:
            kayitlar.append({
                "kategori": kategori,
                "kategori_satiri": kategori_satiri,
                "baslik": baslik,
                "baslik_satiri": baslik_satiri,
                "icerik": "\n".join(buffer).strip(),
            })

    for i, line in enumerate(lines, start=1):
        if line.startswith("## ") and not line.startswith("### "):
            flush()
            kategori = line.lstrip("#").strip()
            kategori_satiri = i
            baslik = None
            buffer = []
        elif line.startswith("### "):
            flush()
            ham_baslik = line.lstrip("#").strip()
            baslik = ONEK_PATTERN.sub("", ham_baslik).strip()
            baslik_satiri = i
            buffer = []
        else:
            if baslik is not None or kategori is not None:
                buffer.append(line)
    flush()
    return kayitlar


def dogrula(kayitlar):
    hatalar = []
    uyarilar = []
    standartlastirma_notlari = []

    # 1. Aynı başlık iki kere mi?
    baslik_satirlari = {}
    for k in kayitlar:
        for parca in re.split(r"[/,]", k["baslik"]):
            kod = parca.strip().upper()
            if not kod:
                continue
            baslik_satirlari.setdefault(kod, []).append(k["baslik_satiri"])

    for kod, satirlar in baslik_satirlari.items():
        if len(satirlar) > 1:
            hatalar.append(
                f"ÇAKIŞMA: '{kod}' kodu {len(satirlar)} kere kullanılmış (satırlar: {satirlar}). "
                f"İkincisi sessizce birincisinin üzerine yazar, biri kaybolur."
            )

    # 2. Kategorisiz başlık var mı?
    for k in kayitlar:
        if k["kategori"] is None:
            uyarilar.append(
                f"KATEGORİSİZ: '### {k['baslik']}' (satır {k['baslik_satiri']}) "
                f"herhangi bir '##' kategorisinin altında değil."
            )

    # 3. Boş içerik / eksik zorunlu alan
    for k in kayitlar:
        icerik = k["icerik"]
        if not icerik.strip():
            hatalar.append(f"BOŞ İÇERİK: '### {k['baslik']}' (satır {k['baslik_satiri']}) hiç içerik taşımıyor.")
            continue

        gorunen_baslik_ust = k["baslik"].upper()
        # Hata mesajı girdileri için "Mesaj Metni" zorunlu
        if "Mesaj Sınıfı" in icerik or "Mesaj No" in icerik:
            if "Mesaj Metni:" not in icerik or re.search(r"Mesaj Metni:\s*$", icerik.split("\n")[-1] if icerik.split("\n") else ""):
                pass  # basit kontrol, ayrıntılı regex aşağıda
            m = re.search(r"Mesaj Metni:\s*(.*)", icerik)
            if not m or not m.group(1).strip():
                hatalar.append(f"EKSİK ALAN: '### {k['baslik']}' (satır {k['baslik_satiri']}) Mesaj Metni boş.")
        else:
            # T-code girdileri için açıklama alanı zorunlu.
            # Not: kaynakta iki farklı isimlendirme var ("Tanım:" eski 23 kayıtta,
            # "Açıklama:" yeni eklenen Z-kodlarında). İkisi de kabul ediliyor,
            # ama bu bir STANDARTLAŞTIRMA notu olarak ayrıca raporlanıyor.
            m = re.search(r"(?:Tanım|Açıklama):\s*(.*)", icerik)
            if not m or not m.group(1).strip():
                uyarilar.append(f"EKSİK ALAN: '### {k['baslik']}' (satır {k['baslik_satiri']}) Tanım/Açıklama boş/yok.")
            elif "Tanım:" in icerik:
                standartlastirma_notlari.append(
                    f"'### {k['baslik']}' (satır {k['baslik_satiri']}) 'Tanım:' kullanıyor, "
                    f"dosyanın çoğu 'Açıklama:' kullanıyor."
                )

    return hatalar, uyarilar, standartlastirma_notlari


def ozet_raporu(kayitlar):
    kategori_sayaci = {}
    for k in kayitlar:
        kat = k["kategori"] or "(kategorisiz)"
        kategori_sayaci[kat] = kategori_sayaci.get(kat, 0) + 1

    print("=" * 60)
    print(f"TOPLAM KAYIT: {len(kayitlar)}")
    print("-" * 60)
    for kat, sayi in kategori_sayaci.items():
        print(f"  {kat}: {sayi} kayıt")
    print("=" * 60)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Kullanım: python validate_kaynak.py kaynak.md")
        sys.exit(1)

    yol = sys.argv[1]
    with open(yol, "r", encoding="utf-8") as f:
        icerik = f.read()

    kayitlar = parcala(icerik)
    ozet_raporu(kayitlar)

    hatalar, uyarilar, standartlastirma_notlari = dogrula(kayitlar)

    if standartlastirma_notlari:
        print(f"\n📝 {len(standartlastirma_notlari)} STANDARTLAŞTIRMA NOTU (hata değil, sadece tutarlılık önerisi):")
        for n in standartlastirma_notlari[:10]:
            print(f"  - {n}")
        if len(standartlastirma_notlari) > 10:
            print(f"  ... ve {len(standartlastirma_notlari) - 10} tane daha.")

    if uyarilar:
        print(f"\n⚠️  {len(uyarilar)} UYARI:")
        for u in uyarilar[:50]:
            print(f"  - {u}")
        if len(uyarilar) > 50:
            print(f"  ... ve {len(uyarilar) - 50} tane daha.")

    if hatalar:
        print(f"\n❌ {len(hatalar)} HATA:")
        for h in hatalar[:50]:
            print(f"  - {h}")
        if len(hatalar) > 50:
            print(f"  ... ve {len(hatalar) - 50} tane daha.")
        print("\nSonuç: BAŞARISIZ. Yukarıdaki hataları düzeltmeden kaynak.md'yi kullanma.")
        sys.exit(1)
    else:
        print("\n✅ Sonuç: HATA YOK. kaynak.md kullanıma hazır.")
        sys.exit(0)
