"""
Excel -> kaynak.md dönüştürücü.

Excel'ler değiştikçe bu scripti yeniden çalıştırabilirsin; her seferinde
zkodlar_ve_hatalar.md dosyasını baştan üretir (elle düzenlediysen üzerine yazar,
o yüzden elle düzenleme yapacaksan .md dosyasında yap, Excel'de değil).

Kullanım:
    python xlsx_to_markdown.py islem_kodlari.xlsx ileti_mesajlari.xlsx cikti.md
"""
import sys
import pandas as pd


def temizle(deger):
    """NaN / None değerleri boş string'e çevirir, diğerlerini string'e çevirir."""
    if pd.isna(deger):
        return ""
    return str(deger).strip()


def islem_kodlari_bolumu(xlsx_path):
    df = pd.read_excel(xlsx_path)
    satirlar = ["## Kurum İçi Z-Kod Listesi (İşlem Kodları)\n"]

    for _, row in df.iterrows():
        kod = temizle(row["İşlem kodu"])
        if not kod:
            continue
        program = temizle(row.get("Program", ""))
        ekran = temizle(row.get("Ekran no.", ""))
        ileti_sinifi = temizle(row.get("İleti sınıfı", ""))
        aciklama = temizle(row.get("İşlem metni", ""))

        satirlar.append(f"### İşlem Kodu: {kod}")
        if aciklama:
            satirlar.append(f"* **Açıklama:** {aciklama}")
        if program:
            satirlar.append(f"* **Program:** `{program}`")
        if ekran and ekran != "0":
            satirlar.append(f"* **Ekran No:** {ekran}")
        if ileti_sinifi:
            satirlar.append(f"* **İleti Sınıfı:** {ileti_sinifi}")
        satirlar.append("")  # boş satır

    return "\n".join(satirlar)


def hata_mesajlari_bolumu(xlsx_path, dil="TR"):
    df = pd.read_excel(xlsx_path)
    df = df[df["Dil anahtarı"] == dil]

    satirlar = [f"## Hata Mesajları (İleti Sınıfları - {dil})\n"]

    for _, row in df.iterrows():
        sinif = temizle(row["Çalışma alanı"])
        no = temizle(row["İleti"])
        metin = temizle(row["İleti metni"])
        if not sinif or not metin:
            continue

        baslik = f"{sinif}-{no}"
        satirlar.append(f"### Hata Mesajı: {baslik}")
        satirlar.append(f"* **Mesaj Sınıfı:** {sinif}")
        satirlar.append(f"* **Mesaj No:** {no}")
        satirlar.append(f"* **Mesaj Metni:** {metin}")
        satirlar.append("")

    return "\n".join(satirlar)


if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Kullanım: python xlsx_to_markdown.py islem_kodlari.xlsx ileti_mesajlari.xlsx cikti.md")
        sys.exit(1)

    islem_xlsx, ileti_xlsx, cikti_yolu = sys.argv[1], sys.argv[2], sys.argv[3]

    bolum1 = islem_kodlari_bolumu(islem_xlsx)
    bolum2 = hata_mesajlari_bolumu(ileti_xlsx, dil="TR")

    with open(cikti_yolu, "w", encoding="utf-8") as f:
        f.write("# Ek Kaynak - Kurumsal Z-Kodları ve Hata Mesajları\n\n")
        f.write(bolum1)
        f.write("\n\n")
        f.write(bolum2)

    print(f"Yazıldı: {cikti_yolu}")
