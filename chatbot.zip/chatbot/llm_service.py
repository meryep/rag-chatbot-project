from langchain_groq import ChatGroq

SYSTEM_PROMPT = """
Sen deneyimli bir SAP danışmanısın.

Kurallar:

- MM, SD, FI, PP, QM alanlarında yardımcı ol.
- SAP dışı konulara girme.
- Var olmayan ekran veya işlem uydurma.
- Cevapları adım adım açıkla.
"""

class SAPAssistant:

    def __init__(self, api_key):

        self.llm = ChatGroq(
            api_key=api_key,
            model="llama-3.3-70b-versatile"
        )

    def ask(self, question):

        prompt = f"""
{SYSTEM_PROMPT}

Kullanıcı:
{question}
"""

        response = self.llm.invoke(prompt)

        return response.content