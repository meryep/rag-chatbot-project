import re

class QuestionRouter:

    Z_CODE_PATTERN = re.compile(
        r"\bZ[A-Z0-9_]+\b",
        re.IGNORECASE
    )

    @classmethod
    def is_z_code_question(cls, question: str) -> bool:
        return bool(
            cls.Z_CODE_PATTERN.search(question)
        )

    @classmethod
    def route(cls, question: str) -> str:
        # Önce gelen soruyu ekrana yazdırıyoruz
        print("SORU:", question)

        # Eğer soru bir "Z Code" sorusu ise RAG rotasını seç
        if cls.is_z_code_question(question):
            print("RAG")
            return "rag"
        
        # Değilse LLM rotasını seç (else yazmaya gerek yoktur, return olduğu için)
        print("LLM")
        return "llm"