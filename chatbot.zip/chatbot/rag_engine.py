import os
import re
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_groq import ChatGroq
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_core.documents import Document
from langchain_core.messages import HumanMessage, AIMessage

# ============================================================
#   KAYNAK.MD'Yİ T-CODE BAŞLIKLARINA GÖRE PARÇALAMA
# ============================================================

def kaynak_md_parcala(icerik: str):
    lines = icerik.split("\n")
    chunks = []
    kategori = "Genel SAP Kodları"
    baslik = None
    buffer = []

    def flush():
        if baslik and buffer:
            metin = f"Kategori: {kategori}\nBaşlık: {baslik}\n" + "\n".join(buffer).strip()
            chunks.append(metin)

    for line in lines:
        # Eğer satır "İşlem Kodu:" veya "Hata Mesajı:" ile başlıyorsa yeni parçaya geç!
        if line.strip().startswith("İşlem Kodu:") or line.strip().startswith("Hata Mesajı:") or line.strip().startswith("T-Code:"):
            flush()
            baslik = line.strip()
            buffer = []
        elif line.startswith("## ") and not line.startswith("### "):
            # Ana kategorileri yakalamak için
            flush()
            kategori = line.lstrip("#").strip()
            baslik = None
            buffer = []
        elif line.startswith("### "):
            flush()
            baslik = line.lstrip("#").strip()
            buffer = []
        else:
            buffer.append(line)
            
    flush()
    return chunks

KELIME_PATTERN = re.compile(r"[A-Za-z0-9_\-]+")


def _z_kod_gibi_mi(kelime: str) -> bool:
    """Bir kelimenin kurumsal 'Z'li kod'veya 'zLİ' kod gibi görünüp görünmediğine bakar
    (SAP özel geliştirme namespace kuralı: kurumsal özel kodlar/mesaj sınıfları
    Z ile başlar). En az 4 karakter, Z ile başlıyor, devamında en az bir
    alfanümerik karakter olmalı."""
    k = kelime.upper()
    return len(k) >= 4 and k.startswith("Z") and any(c.isalnum() for c in k[1:])


SYSTEM_PROMPT = """Sen kıdemli bir SAP HANA ve süreç asistanısın (Jelly). Kurum içindeki kullanıcılara SAP T-code ve süreçlerinde yardımcı oluyorsun.

Eğer kullanıcının sorusu günlük bir sohbet (selamlaşma, teşekkür vb.) ise veya sana verilen Bağlam (Context) içinde sorunun cevabı HİÇ YOKSA, o zaman bağlamı tamamen görmezden gel ve normal, arkadaş canlısı ve zeki bir yapay zeka asistanı olarak kendi genel bilgini kullanarak doğal bir sohbet diliyle cevap ver.

{guven_talimati}

GENEL KURALLAR:
- Konu SAP dışıysa sadece şunu söyle: "Bu konu yetki alanımın dışında, ilgili IT birimine danışabilirsiniz."
- Asla var olmayan buton, ekran elemanı veya menü adı uydurma. Sadece gerçek T-code ve alan adları kullan.
- Sen Türkçe yanıt veren bir SAP HANA uzmanısın. Yanıtlarını YALNIZCA Türkçe dilinde oluştur. Kesinlikle başka bir dilde kelime kullanma.

CEVAP FORMATI (ESNEK VE DOĞAL):
- Robotik olma, akıcı ve doğal bir dil kullan.
- Kullanıcı sadece bir kod soruyorsa (örn: "Fatura takip kodu nedir?"), doğrudan kodu ver ve kısaca ne işe yaradığını söyle. Zoraki listeler veya adımlar uydurma.
- Eğer kullanıcı bir hata çözümü veya süreç adımları soruyorsa, o zaman anlaşılır olması için numaralı/maddeli listeler kullanabilirsin.
- Hangi ekranda olunduğu belirsizse ve yardıma devam edebilmek için bu bilgiyi alman gerekiyorsa cevabının sonuna nazik bir soru ekle.
- Önceki mesajları (varsa) hatırla ve bağlam olarak kullan.

ÖNEMLİ - TAKİP SORULARI:
Cevabının EN SONUNA, kullanıcının tıklayıp devam edebilmesi için aşağıdaki formatta tam olarak 2-3 kısa takip sorusu ekle:
---SORULAR---
Soru 1
Soru 2
Soru 3

Bağlam:
<context>
{context}
</context>
"""

GUVEN_TALIMATLARI = {
    "HIGH": (
        "GÜVEN SEVİYESİ: YÜKSEK. Kullanıcının sorduğu T-code/kod için Bağlam'da "
        "tam ve net bir eşleşme var (kurumsal kaynaktan doğrulanmış). Bu bilgiyi "
        "birebir kullan, istersen madde/liste ile zenginleştirebilirsin."
    ),
    "GENEL": (
        "GÜVEN SEVİYESİ: GENEL SAP SORUSU. Kullanıcının sorusu kurumsal özel bir "
        "koda (Z'li kod) değil, standart/kamuya açık SAP bilgisine dayanıyor "
        "(örn. MM02, QA32 gibi herkesin bildiği T-code'lar, genel süreçler, genel "
        "kavramlar). Bağlam'da tam bir eşleşme olmasa da SORUN DEĞİL - bunlar "
        "kamuya açık, senin de zaten bildiğin standart bilgilerdir. Kendi SAP "
        "bilgini TAM GÜVENLE, HİÇBİR disclaimer/uyarı EKLEMEDEN, zengin ve adım "
        "adım şekilde kullan. Bağlam'da yerel/anlamsal olarak yakın bir bilgi "
        "varsa onu da dahil et ve önceliklendir. "
        "ARAMA / SÜREÇ SORUSU. Kullanıcı tam bir işlem kodu "
        "söylememiş veya bir süreci (örn: 'paperwork nedir', 'hangi kod kullanılır', vb.) "
        "soruyor olabilir. Lütfen sana verilen Bağlam'ı (Context) DİKKATLİCE OKU. "
        "Eğer kullanıcının aradığı işleme, uygulamaya veya kelimeye ait bir Z'li kod "
        "(kurumsal özel kod) veya standart SAP kodu bağlamda geçiyorsa, KESİNLİKLE "
        "öncelikle o kodu ve açıklamasını kullanıcıya sun. Bağlamda hiçbir eşleşme "
        "yoksa, kendi genel SAP bilgini kullan."
    ),
}


class RAGChatbot:
    def __init__(self, vectorstore=None, veri_yolu=None, groq_api_key=None):
        self.vectorstore = vectorstore
        self.veri_yolu = veri_yolu or "kaynak.md"
        self.groq_api_key = groq_api_key or os.environ.get("GROQ_API_KEY")

        self.llm = ChatGroq(
            model_name="llama-3.3-70b-versatile",
            temperature=0.2,
            groq_api_key=self.groq_api_key,
        )

        self.prompt_template = ChatPromptTemplate.from_messages([
            ("system", SYSTEM_PROMPT),
            MessagesPlaceholder("gecmis", optional=True),
            ("human", "{input}"),
        ])

        self.raw_chunks = []
        self.baslik_to_chunk = {}
        embeddings = HuggingFaceEmbeddings(model_name="paraphrase-multilingual-MiniLM-L12-v2")

        if not self.vectorstore:
            try:
                hedef_dizin = os.path.dirname(self.veri_yolu) if os.path.isfile(self.veri_yolu) else self.veri_yolu
                if not hedef_dizin:
                    hedef_dizin = "."

                if os.path.exists(os.path.join(hedef_dizin, "index.faiss")):
                    self.vectorstore = FAISS.load_local(hedef_dizin, embeddings, allow_dangerous_deserialization=True)
                    self.raw_chunks = [d.page_content for d in self.vectorstore.docstore._dict.values()]
                    self.baslik_to_chunk = self._baslik_tablosu_olustur(self.raw_chunks)
                else:
                    print(f"\n[SİSTEM KONTROLÜ] Python'un aradığı dosya: {self.veri_yolu}")
                    print(f"[SİSTEM KONTROLÜ] Dosya klasörde var mı?: {os.path.exists(self.veri_yolu)}")
                    
                    if os.path.exists(self.veri_yolu) and os.path.isfile(self.veri_yolu):
                        with open(self.veri_yolu, "r", encoding="utf-8") as f:
                            icerik = f.read()

                        self.raw_chunks = kaynak_md_parcala(icerik)
                        self.baslik_to_chunk = self._baslik_tablosu_olustur(self.raw_chunks)
                        docs = [Document(page_content=t) for t in self.raw_chunks]
                        self.vectorstore = FAISS.from_documents(docs, embeddings)

                        try:
                            self.vectorstore.save_local(hedef_dizin)
                        except Exception as kaydetme_hatasi:
                            print(f"FAISS index kaydedilemedi (önemli değil): {kaydetme_hatasi}")
            except Exception as e:
                print(f"Vektör veritabanı oluşturulurken/yüklenirken hata: {e}")

        self.baslik_to_chunk = self._baslik_tablosu_olustur(self.raw_chunks)
        tum_kodlar = list(self.baslik_to_chunk.keys())
        print(f"\n[AJAN] Sözlüğe Yüklenen TOPLAM Kod Sayısı: {len(tum_kodlar)}")
        print(f"[AJAN] İlk 5 kod: {tum_kodlar[:5]}")
        print(f"[AJAN] Son 5 kod: {tum_kodlar[-5:]}")
        
        if self.vectorstore:
            self.retriever = self.vectorstore.as_retriever(
                search_type="similarity",
                # DÜZELTME BURADA YAPILDI (4'ten 15'e çıkarıldı)
                search_kwargs={"k": 15}, 
            )
        else:
            self.retriever = None

    # --------------------------------------------------------
    @staticmethod
    def _baslik_tablosu_olustur(raw_chunks):
        onek_pattern = re.compile(
            r"^(İşlem Kodu|Hata Mesajı|T-Code|T-Kodu|Kod)\s*:\s*", re.IGNORECASE
        )
        tablo = {}
        for chunk in raw_chunks:
            m = re.search(r"Başlık:\s*(.+)", chunk)
            if not m:
                continue
            baslik_satiri = onek_pattern.sub("", m.group(1))
            for parca in re.split(r"[/,]", baslik_satiri):
                kod = parca.strip().upper()
                if kod:
                    tablo[kod] = chunk
        return tablo

    def _keyword_eslesme(self, user_input: str):
        kelimeler = {k.upper() for k in KELIME_PATTERN.findall(user_input)}
        eslesenler = []
        for kelime in kelimeler:
            if kelime in self.baslik_to_chunk:
                eslesenler.append(self.baslik_to_chunk[kelime])
        return eslesenler

    def siniflandir(self, user_input: str):
        if self._keyword_eslesme(user_input):
            return "HIGH", []

        kelimeler = {k.upper() for k in KELIME_PATTERN.findall(user_input)}
        z_kod_adaylari = [k for k in kelimeler if _z_kod_gibi_mi(k)]
        if z_kod_adaylari:
            return "Z_KOD_YOK", z_kod_adaylari

        return "GENEL", []

    def web_aramasi_denenmeli_mi(self, user_input: str) -> bool:
        sinif, _ = self.siniflandir(user_input)
        return sinif == "GENEL"

    def _context_ve_guven(self, user_input: str, web_content: str = None):
        sinif, z_kod_adaylari = self.siniflandir(user_input)

        keyword_docs = self._keyword_eslesme(user_input) if sinif == "HIGH" else []

        vector_docs = []
        if self.vectorstore and sinif != "Z_KOD_YOK":
            try:
                # DÜZELTME BURADA YAPILDI (4'ten 15'e çıkarıldı)
                vector_sonuclar = self.vectorstore.similarity_search_with_score(user_input, k=15)
                vector_docs = [doc.page_content for doc, _skor in vector_sonuclar]
            except Exception as e:
                print(f"Vektör arama hatası: {e}")

        guven = sinif

        if guven == "Z_KOD_YOK":
            context = (
                f"(Kullanıcının bahsettiği '{', '.join(z_kod_adaylari)}' kodu/kaydı "
                f"kurumsal kaynağımızda BULUNAMADI.)"
            )
        else:
            parcalar = []
            gorulen = set()
            for t in keyword_docs + vector_docs:
                if t not in gorulen:
                    parcalar.append(t)
                    gorulen.add(t)
            context = (
                "\n\n---\n\n".join(parcalar)
                if parcalar
                else "(Yerel dokümantasyonda tam bir kayıt yok, bu genel bir SAP sorusu - kendi bilgini kullanabilirsin.)"
            )
            if web_content:
                context = f"[Web'den çekilen ek kaynak]\n{web_content}\n\n---\n\n{context}"

        print("\n" + "=" * 60)
        print(f"[DEBUG] Kullanıcı sorgusu: {user_input!r}")
        print(f"[DEBUG] Keyword eşleşmesi bulundu mu: {len(keyword_docs) > 0} ({len(keyword_docs)} adet)")
        print(f"[DEBUG] Z'li kod adayları (kaynakta yok): {z_kod_adaylari}")
        print(f"[DEBUG] SINIFLANDIRMA: {guven}")
        print(f"[DEBUG] LLM'e giden TAM context:\n{context[:3000]}")
        print("=" * 60 + "\n")

        return context, guven, z_kod_adaylari

    # --------------------------------------------------------
    def soru_sor(self, user_input: str, gecmis=None, web_content: str = None):
        try:
            context, guven, z_kod_adaylari = self._context_ve_guven(user_input, web_content=web_content)

            if guven == "Z_KOD_YOK":
                guven_talimati = (
                    f"GÜVEN SEVİYESİ: Z'Lİ KOD BULUNAMADI. Kullanıcı "
                    f"{', '.join(z_kod_adaylari)} gibi kurumsal özel bir kod/kayıt "
                    "soruyor ama bu Bağlam'da YOK. Bu kesinlikle bilinemeyecek bir "
                    "şeydir çünkü kurumsal özel kodlar/mesaj sınıfları hiçbir genel "
                    "veya kamuya açık kaynakta bulunmaz - tahmin etmek saf halüsinasyon "
                    "olur. SADECE ve TAM OLARAK şunu söyle, başka HİÇBİR ŞEY ekleme: "
                    "\"Bu Z'li kod/kayıt kurumsal kaynağımızda bulunamadı. Z'li kodlar "
                    "için ilgili IT/BASIS birimine danışmanızı öneririm.\" Hiçbir "
                    "tahmin, hiçbir liste, hiçbir genel SAP bilgisi EKLEME."
                )
            else:
                guven_talimati = GUVEN_TALIMATLARI[guven]

            lc_gecmis = []
            if gecmis:
                for m in gecmis[-6:]:
                    if m["role"] == "user":
                        lc_gecmis.append(HumanMessage(content=m["content"]))
                    else:
                        lc_gecmis.append(AIMessage(content=m["content"]))

            messages = self.prompt_template.format_messages(
                context=context,
                input=user_input,
                gecmis=lc_gecmis,
                guven_talimati=guven_talimati,
            )
            response = self.llm.invoke(messages)
            ham_cevap = response.content

            cevap, sorular = self._sorulari_ayikla(ham_cevap)
            return cevap, sorular, guven
        except Exception as e:
            return f"Sorgu işlenirken bir hata oluştu: {str(e)}", [], "Z_KOD_YOK"

    @staticmethod
    def _sorulari_ayikla(metin: str):
        if "---SORULAR---" not in metin:
            return metin.strip(), []
        ana, sorular_blok = metin.split("---SORULAR---", 1)
        sorular = [s.strip("-• ").strip() for s in sorular_blok.strip().split("\n") if s.strip()]
        return ana.strip(), sorular[:3]

    def arama_terimi_uret(self, sorgu: str) -> str:
        try:
            cevap = self.llm.invoke([
                HumanMessage(content=(
                    "Aşağıdaki SAP ile ilgili soruyu, help.sap.com'da arama yapmaya uygun "
                    "2-4 kelimelik KISA İngilizce SAP terimine çevir. SADECE terimi yaz, "
                    "başka hiçbir açıklama, tırnak işareti veya noktalama ekleme.\n\n"
                    f"Soru: {sorgu}\n\nİngilizce arama terimi:"
                ))
            ])
            terim = cevap.content.strip().strip('"').strip("'").strip()
            return terim if terim else sorgu
        except Exception:
            return sorgu

    def web_icerigi_alakali_mi(self, orijinal_soru: str, web_metni: str) -> bool:
        try:
            cevap = self.llm.invoke([
                HumanMessage(content=(
                    "Bir kullanıcı şu SAP ERP (T-code, malzeme, finans, lojistik, "
                    "kurumsal süreç) sorusunu sordu:\n"
                    f"\"{orijinal_soru}\"\n\n"
                    "Aşağıdaki web sayfası içeriği bu soruyla GERÇEKTEN alakalı mı? "
                    "Not: help.sap.com; SAP Commerce/hybris, SAP Analytics Cloud, "
                    "NetWeaver, SiteScope gibi FARKLI ürünlerin dokümantasyonunu da "
                    "barındırıyor - kelime benzerliği olsa da farklı bir ürünün/modülün "
                    "sayfasıysa ALAKASIZ say. Sadece tek kelime yaz: EVET veya HAYIR.\n\n"
                    f"İçerik:\n{web_metni[:1500]}"
                ))
            ])
            return cevap.content.strip().upper().startswith("EVET")
        except Exception:
            return False

    def get_retriever(self):
        return self.retriever

    def get_prompt(self):
        return self.prompt_template

    def get_llm(self):
        return self.llm